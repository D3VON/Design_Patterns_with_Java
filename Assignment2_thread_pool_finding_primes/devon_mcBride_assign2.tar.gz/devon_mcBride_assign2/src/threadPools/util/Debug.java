
package threadPools.util;

/**
 * @author      Devon McBride <dmcbrid1@binghamton.edu> 
 *                            <devonmcb@yahoo.com>
 * @since       1.6.0_16
 * 
 * ...for Assignment 2, cs342, Program Design Patterns
 * 
 * Code template provided by Professor Madhusudan Govindaraju
 */

public class Debug {
    public static int DEBUG_VALUE;

}
