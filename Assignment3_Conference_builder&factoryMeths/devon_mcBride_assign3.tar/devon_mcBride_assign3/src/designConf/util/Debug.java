package designConf.util;

/**
 * @author      Devon McBride       <dmcbrid1@binghamton.edu> 
 * @author      Thomas John Orourke <torourk2@binghamton.edu>
 * @author      Daniel Scott        <dscott5@binghamton.edu>
 *  
 * @since       1.6.0_16
 * 
 * ...for Assignment 3, cs342, Program Design Patterns
 * 
 * Code template provided by Professor Madhusudan Govindaraju
 * 
 */
public class Debug {
    public static int DEBUG_VALUE;
}

