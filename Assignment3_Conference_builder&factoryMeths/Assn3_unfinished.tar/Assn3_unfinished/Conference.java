
public abstract class Conference
{
	protected String currency = "Euros";
	private String carbon;
	private String time;
	
	
	protected Cost confCost;
	protected String schedule;

	public abstract void setupSchedule(Activities activities);
	
	public void clearSchedule()
	{
		schedule = "\n";
	}

	public double getFee()
	{
		return confCost.getCost();
	}

	public void printSchedule()
	{
		System.out.println(schedule);
	}

	/**
	 * @param time the time units to set
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * @return the time units
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param carbon the carbon measurement to set
	 */
	public void setCarbon(String carbon) {
		this.carbon = carbon;
	}

	/**
	 * @return the carbon measurement
	 */
	public String getCarbon() {
		return carbon;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return this.currency;
	}

}