
public class BUConUnitFactory implements UnitFactory {
	
	Conference conf;
	
	BUConUnitFactory(Conference conf){
		this.conf = conf;
	}
		
	@Override
	public Cost createCostUnits(double fee) 
	{
		Cost cost = null;
		
		//System.out.println(this.conf.getCurrency());
	
		if( conf.getCurrency().equals("Dollars") )
		{
			cost = new CostDollar(fee);
		}
		else if (conf.getCurrency() == "Euros")
		{
			cost = new CostEuro(fee);
		}
		
		return cost;
	}

	@Override
	public Time createTimeUnits() {
		if(conf.getTime().equals("Minutes"))
		{
			return new TimeMinutes(0);
		}
		/* not yet implemented
		else if (conf.getTime().equals("Hours"))
		{
			return new TimeHours(0);
		}
		*/
		else
			return null;
	}

	@Override
	public CarbonFootPrint createCarbonUnits() {
		if(conf.getCarbon().equals("Tons"))
		{
			return new CFPTons(0);
		}
		/* not yet implemented
		else if (conf.getCarbon().equals("Kilos"))
		{
			return new CFPTons(0);
		}
		*/
		else
			return null;
	}
	
	
	public String toString(){
		return ("This is BUConUnitFactory!");
	}

}
