
public interface Activities
{
	public String register();
	public String presentationChoice();
	public String transportChoice();
	public String labChoice();
	public String restaurantChoice();
}


