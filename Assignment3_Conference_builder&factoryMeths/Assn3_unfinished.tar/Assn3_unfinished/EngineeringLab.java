
public class EngineeringLab extends Lab
{

	public EngineeringLab()
	{
		name = "Engineering Lab, room G7,";
		time = new TimeMinutes(48);
		cfp = new CFPTons(0.0008);
	}
}