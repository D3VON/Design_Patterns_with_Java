
public class LibraryGroundLab extends Lab
{

	public LibraryGroundLab()
	{
		name = "Library North Ground room 103";
		time = new TimeMinutes(120);
		cfp = new CFPTons(0.0065);
	}
}