

public class BUVisa extends CreditCard
{

	public BUVisa(double cost)
	{		
		double discount = 10.0;		
		
		cost *= ((100.0 - discount) / 100.0);
		
		this.cost = new CostDollar(cost);
		
		name = "BU Alumni Platinum Visa";
	}
}