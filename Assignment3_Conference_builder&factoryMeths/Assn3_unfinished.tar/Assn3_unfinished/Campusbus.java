
public class Campusbus extends Transport
{

	public Campusbus()
	{
		name = "OCC Blue Bus,";
		time = new TimeMinutes(3);
		cfp = new CFPTons(0.0009);
	}
}