
public class CostEuro implements Cost
{
	private double cost;
	
	public CostEuro(double cost)
	{
		// a class should be implemented to get exchange rates thusly:
		//this.cost = cost * Currency.getExchangeRate("Euro");
		this.cost = cost * .75;
	}

	public double getCost()
	{
		return cost;
	}

	public void setCost(double cost)
	{
		this.cost = cost;
	}

	public String toString()
	{
		return ("�" + cost);
	}
}