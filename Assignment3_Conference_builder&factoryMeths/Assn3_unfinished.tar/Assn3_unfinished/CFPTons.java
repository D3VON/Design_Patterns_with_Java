
public class CFPTons implements CarbonFootPrint
{
	private double carbonFootPrint;

	public CFPTons(double carbonFootPrint)
	{
		this.carbonFootPrint = carbonFootPrint;
	}

	@Override
	public String toString()
	{
		return (carbonFootPrint + " tons of CO2");
	}
}