
public class FactoryMethod extends Presentation
{

	public FactoryMethod()
	{
		name = "Factory Method Pattern Presentation";
		time = new TimeMinutes(120);
		cfp = new CFPTons(0.0008);
	}
}