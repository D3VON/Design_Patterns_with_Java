
public abstract class Transport
{
	protected CarbonFootPrint cfp;
	protected Time time;
	protected String name;

	public String toString()
	{
		return ("Going by " + name + " will take " + time.toString()
				+ " and have a carbon footprint of "
				+ cfp.toString() + ".\n");
	}
}