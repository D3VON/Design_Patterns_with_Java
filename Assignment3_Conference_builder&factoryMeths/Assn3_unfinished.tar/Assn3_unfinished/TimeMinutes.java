
public class TimeMinutes implements Time
{
	private int minutes;

	public TimeMinutes(int minutes)
	{
		this.minutes = minutes;
	}

	public String toString()
	{
		return (minutes + " minutes");
	}
}