
public abstract class Restaurant
{
	protected CarbonFootPrint cfp;
	protected Cost cost;
	protected Time time;
	protected String name;

	public String toString()
	{
		return ("Your dinner at " + name + " will cost "
				+ cost.toString() + ", and will take " + time.toString()
				+ ", and has a carbon footprint of "
				+ cfp.toString() + ".\n");
	}
}