
public class Visa extends CreditCard
{
	public Visa(double cost)
	{
		this.cost = new CostDollar(cost);
		name = "Visa";
	}
}