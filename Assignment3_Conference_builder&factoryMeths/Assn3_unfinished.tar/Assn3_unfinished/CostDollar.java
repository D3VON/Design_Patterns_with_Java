
public class CostDollar implements Cost
{
	private double cost;
	
	public CostDollar(double cost)
	{
		this.cost = cost;
	}

	public double getCost()
	{
		return cost;
	}

	public void setCost(double cost)
	{
		this.cost = cost;
	}

	public String toString()
	{
		return ("$" + cost);
	}
}