
public class BUConference extends Conference
{	
	public BUConference(String currency)
	{
		this.currency = currency;
		UnitFactory unitFactory = new BUConUnitFactory(this);
		
		confCost = unitFactory.createCostUnits(100.00); // unfortuantely hard-coded conference fee
		schedule = "\n";
	}
	
	/* The Builder Pattern: receive info about components 
	 * that has been gathered into an intermediate object 
	 * that has stored data about various objects needed 
	 * to be "stitched together"
	 */	
	public void setupSchedule(Activities activities)
	{
		// assemble the texts of activities in this order
		// (classic builder pattern)
		schedule += activities.register();
		schedule += activities.presentationChoice();
		schedule += activities.transportChoice();
		schedule += activities.labChoice();
		schedule += activities.restaurantChoice();
	}
	
	public String toString (){
		return ("This is BConference");		
	}
}
