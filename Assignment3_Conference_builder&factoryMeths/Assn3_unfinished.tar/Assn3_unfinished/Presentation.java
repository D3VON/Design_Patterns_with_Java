
public abstract class Presentation
{
	protected CarbonFootPrint cfp;
	protected Time time;
	protected String name;


	public String toString()
	{
		return ("You have chosen to attend the " 
				+ name + ", which will take "
				+ time.toString() + ", and have a carbon footprint of "
				+ cfp.toString() + ".\n");
	}
}