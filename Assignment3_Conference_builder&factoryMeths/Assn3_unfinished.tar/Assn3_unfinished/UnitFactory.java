
public interface UnitFactory {
	public Cost createCostUnits(double x);
	public Time createTimeUnits();
	public CarbonFootPrint createCarbonUnits();
}
