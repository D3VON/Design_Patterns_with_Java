
public class LemongrassRestaurant extends Restaurant
{

	public LemongrassRestaurant(String currency)
	{
		name = "Lemongrass Kitchen & Lounge";
		time = new TimeMinutes(60);
		cfp = new CFPTons(0.0010);
		
		
		cost = new CostEuro(35);
	}
}