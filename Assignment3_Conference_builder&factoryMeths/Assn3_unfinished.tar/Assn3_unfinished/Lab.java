
public abstract class Lab
{
	// prolly should be private with setters and getters.  
	// when would anyone *ever* use protected for a data member?
	
	// just did protected so Eclipse wouldn't complain so much
	
	protected CarbonFootPrint cfp;
	protected Time time;
	protected String name;

	public String toString()
	{
		return ("The programming contest you chose is at " 
				+ name + ", and will take "
				+ time.toString() + ", and has a carbon footprint of "
				+ cfp.toString() + ".\n");
	}
}