
public class AcademicAPod extends Lab
{

	public AcademicAPod()
	{
		name = "Academic A Pod";
		cfp = new CFPTons(0.0075);
		time = new TimeMinutes(110);
	}
}