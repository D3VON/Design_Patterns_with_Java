public class BUActivities implements Activities
{
	protected CreditCard card;
	protected Lab lab;
	protected Presentation presentation;
	protected Transport transport;
	protected Restaurant restaurant;

	public BUActivities(CreditCard card, Lab lab, Presentation presentation, 
						Transport transport, Restaurant restaurant)
	{
		this.card 		  = card;
		this.presentation = presentation;
		this.transport 	  = transport;
		this.lab 		  = lab;
		this.restaurant   = restaurant;
	}

	public String register()
	{
		return card.toString();
	}

	public String presentationChoice() 
	{
		return presentation.toString();
	}

	public String transportChoice() 
	{
		return transport.toString();
	}

	public String labChoice()
	{
		return lab.toString();
	}

	public String restaurantChoice()
	{
		return restaurant.toString();
	}
}