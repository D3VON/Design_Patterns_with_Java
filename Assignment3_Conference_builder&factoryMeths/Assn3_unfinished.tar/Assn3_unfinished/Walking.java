
public class Walking extends Transport
{
	public Walking()
	{
		cfp = new CFPTons(0.001);
		time = new TimeMinutes(20);
		name = "walking and taking the stairs,";
	}
}