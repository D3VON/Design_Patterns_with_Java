
public interface CarbonFootPrint
{
	public String toString();
}