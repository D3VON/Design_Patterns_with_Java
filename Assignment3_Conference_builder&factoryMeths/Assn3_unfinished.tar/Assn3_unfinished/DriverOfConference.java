
public class DriverOfConference
{
	public static void main(String args[]) 
	{
		
		/*
		 * A web-based registration would generate an object 
		 * to wrap these parameters.  Due to time constraints
		 * (and pain thresholds), we've given these parameters
		 * simply as strings. 
		 * 
		 * These parameters are used by the factory methods to
		 * instantiate the appropriate objects. 
		 * 
		 */
		String currency = "Euros";		
		
//===================================================================
//	ATTENDEE #1	
//===================================================================
		
		// this is the builder object
		Conference buConf = new BUConference(currency);
		
		//System.out.println(buConf.toString());
		
		buConf.setCurrency(currency); // should use enum
		
		//System.out.println(buConf.getCurrency());
		
		//buConf.setCarbon("Tons");
		//buConf.setTime("Minutes");

		// activity choices
		CreditCard card = new BUVisa(buConf.getFee());
		
		
		
		Presentation presentation = new FactoryMethod();
		Transport transport = new Campusbus();
		Lab lab = new AcademicAPod();
		Restaurant restaurant = new PSRestaurant(currency);

		// the hard-coded choices stored "in an elegant way"
		Activities activities = new BUActivities(card, lab, presentation,
											     transport, restaurant);
		
		buConf.setupSchedule(activities);
		buConf.printSchedule();

		buConf.clearSchedule();// in real life, 
		                       // would be sent to web browser,
		                       // or stored in a database

/*===================================================================
//			ATTENDEE #2	
//===================================================================		
		
		// choose different activities
		card = new Amex(buConf.getFee());
		presentation = new State();
		transport = new Elevators();
		lab = new EngineeringLab();
		restaurant = new No5Restaurant();

		activities = new BUActivities(card, lab, presentation,
									  transport, restaurant);

		buConf.setupSchedule(activities);
		buConf.printSchedule();

		buConf.clearSchedule();
	*/
//===================================================================
//		ATTENDEE #3	
//===================================================================	
		
		card = new MasterCard(buConf.getFee());
		presentation = new Observer();
		transport = new Walking();
		lab = new AcademicAPod();
		restaurant = new LemongrassRestaurant(currency);

		activities = new BUActivities(card, lab, presentation,
									  transport, restaurant);

		buConf.setupSchedule(activities);
		buConf.printSchedule();

		
//===================================================================
//							FREE UP MEMORY
//===================================================================
				
		card = null;
		presentation = null;
		transport = null;
		lab = null;
		restaurant = null;
		buConf = null;
	}
}