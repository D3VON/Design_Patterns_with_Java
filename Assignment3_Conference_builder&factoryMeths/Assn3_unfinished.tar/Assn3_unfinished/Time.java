
public interface Time
{
	public String toString();
}