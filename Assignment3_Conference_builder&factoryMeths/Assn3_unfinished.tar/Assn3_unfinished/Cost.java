
public interface Cost
{
	public double getCost();
	public void setCost(double cost);
	public String toString();
}