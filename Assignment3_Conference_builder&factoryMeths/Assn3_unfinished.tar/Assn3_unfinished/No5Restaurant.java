
public class No5Restaurant extends Restaurant
{

	public No5Restaurant() 
	{
		name = "The No. 5 Restaurant";
		cfp = new CFPTons(0.0003);
		cost = new CostDollar(60);
		time = new TimeMinutes(80);
	}
}