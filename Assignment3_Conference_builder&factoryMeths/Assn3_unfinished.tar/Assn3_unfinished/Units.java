//import java.util.ArrayList;

public class Units {
	
	private static String cfpUnits;
	private static String timeUnits;
	private static String currency;
	
	public enum Currency {				
		 DOLLAR(1.0), EURO(.86), POUND(.66), YEN(75.0);
		 private double rate;

		 // CONSTRUCTOR ??????
		 // this code is so perplexing to me!!!!
		 private Currency(double r) { 
		   rate = r;         
		 }

		 public double getRate() {
		   return rate;
		 }
	}	 
	
	// Currency.EURO.getRate()
	
	

}
