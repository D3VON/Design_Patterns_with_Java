
public class MasterCard extends CreditCard
{

	public MasterCard(double cost)
	{
		this.cost = new CostDollar(cost);
		name = "MasterCard";
	}
}