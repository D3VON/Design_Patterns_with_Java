
public class Amex extends CreditCard
{
	public Amex(double cost)
	{
		this.cost = new CostDollar(cost);
		name = "American Express";
	}
}