
public abstract class CreditCard
{
	protected Cost cost;
	protected String name;

	public String toString()
	{
		return ("The registration fee is " + cost.toString() + 
				" and you are paying with your " + name + " card.\n");
	}
}