
public class Elevators extends Transport
{

	public Elevators()
	{
		name = "elevators & tunnels";
		time = new TimeMinutes(12);
		cfp = new CFPTons(0.0001);
	}
}