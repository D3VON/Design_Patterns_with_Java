
public class State extends Presentation
{

	public State()
	{
		name = "State Pattern Presentation";
		time = new TimeMinutes(145);
		cfp = new CFPTons(0.0012);
	}
}