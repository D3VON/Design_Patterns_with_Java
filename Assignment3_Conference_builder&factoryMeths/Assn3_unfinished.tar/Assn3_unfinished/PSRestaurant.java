
public class PSRestaurant extends Restaurant
{
	public PSRestaurant(String currency)
	//public PSRestaurant()
	{
		name = "P.S. Restaurant";
		cfp = new CFPTons(0.0007);
		cost = new CostDollar(50);
		
		/*
		 * I think we can get some a point or two if we just 
		 * mention we would use a factory method here
		 * to create the right Cost object.
		 * 
		 * The constructor would receive a string 
		 * (or enum, if ya like), like the pizza 
		 * example in the Head First book. 
		 * 
		 * --same for CFPTons and Time
		 * 
		 * --suffice it to say we have interfaces, here called 
		 * "CarbonFootPrint" and "Time"
		 * 
		 */
		 
		
		if(currency.equals("Dollar"))
			cost = new CostDollar(50);
		else if (currency.equals("Euro"))
			cost = new CostEuro(50);
			
		time = new TimeMinutes(95);
	}
}