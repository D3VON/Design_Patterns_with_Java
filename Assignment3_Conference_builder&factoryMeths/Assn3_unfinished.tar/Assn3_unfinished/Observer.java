
public class Observer extends Presentation
{

	public Observer()
	{
		name = "Observer Pattern Presentation";
		cfp = new CFPTons(0.0075);
		time = new TimeMinutes(100);
	}
}