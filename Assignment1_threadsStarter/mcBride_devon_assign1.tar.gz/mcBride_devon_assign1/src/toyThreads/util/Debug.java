
package toyThreads.util;

/**
 * @author      Devon McBride <dmcbrid1@binghamton.edu> 
 *                         or <devonmcb@yahoo.com>
 * @since       1.6.0_16
 * 
 * ...for Assignment 1, cs342, Program Design Patterns
 * 
 * Code template provided by Professor Madhusudan Govindaraju
 */
public class Debug {
    public static int DEBUG_VALUE;

}
